const COLORS = {
    white: "#FFFFFF",
    black: "#222222",
    primary: "#007260",
    // #99A1E8
    secondary: "#99A1E8",
    grey: "#CCCCCC"

}

export default COLORS;