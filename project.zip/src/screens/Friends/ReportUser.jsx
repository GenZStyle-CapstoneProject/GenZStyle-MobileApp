import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useNavigation } from '@react-navigation/native';

const ReportUser = () => {
    const navigation = useNavigation();
    const [reasons, setReasons] = useState({
        dislike: false,
        behavior: false,
        notSuitable: false,
        spamOrScam: false,
        other: false,
    });

    const [otherReason, setOtherReason] = useState('');

    const handleGoBack = () => {
        navigation.goBack();
    };

    const handleSave = () => {
        // Perform actions based on selected reasons and otherReason
        console.log('Selected reasons:', reasons);
        console.log('Other reason:', otherReason);
        // Add your logic to handle the selected reasons
        // For example, you can send this information to a server
    };

    const toggleReason = (reason) => {
        setReasons((prevReasons) => ({
            ...prevReasons,
            [reason]: !prevReasons[reason],
        }));
    };

    return (
        <View style={styles.container}>
            <View style={styles.headerContainer}>
                <TouchableOpacity onPress={handleGoBack} style={styles.headerBack}>
                    <Icon name="keyboard-arrow-left" size={30} color="black" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Báo cáo người dùng</Text>
                <TouchableOpacity style={styles.headerSave} onPress={handleSave}>
                    <Text style={styles.headerSaveText}>Hoàn tất</Text>
                </TouchableOpacity>
            </View>

            <View style={styles.reasonContainer}>
                <ReasonCheckbox
                    label='Tôi không thích người dùng này'
                    checked={reasons.dislike}
                    onPress={() => toggleReason('dislike')}
                />
                <ReasonCheckbox
                    label='Hành vi của người dùng này không hợp với tôi'
                    checked={reasons.behavior}
                    onPress={() => toggleReason('behavior')}
                />
                <ReasonCheckbox
                    label='Người dùng này không nên xuất hiện GenZStyle'
                    checked={reasons.notSuitable}
                    onPress={() => toggleReason('notSuitable')}
                />
                <ReasonCheckbox
                    label='Người dùng này gửi thư rác hoặc lừa đảo'
                    checked={reasons.spamOrScam}
                    onPress={() => toggleReason('spamOrScam')}
                />
                <ReasonCheckbox
                    label='Lý do khác'
                    checked={reasons.other}
                    onPress={() => toggleReason('other')}
                />
                {reasons.other && (
                    <TextInput
                        style={styles.otherReasonInput}
                        placeholder='Nhập lý do khác'
                        value={otherReason}
                        onChangeText={setOtherReason}
                    />
                )}
            </View>
        </View>
    );
};

const ReasonCheckbox = ({ label, checked, onPress }) => {
    return (
        <TouchableOpacity style={styles.checkboxContainer} onPress={onPress}>
            <View style={styles.checkbox}>
                {checked && <Icon name="check" size={20} color="black" />}
            </View>
            <Text style={styles.checkboxLabel}>{label}</Text>
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingHorizontal: 10,
        paddingTop: 50,
        backgroundColor: 'white',
    },
    headerContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: 15,
    },
    headerBack: {
        right: 20,
    },
    headerTitle: {
        flex: 1,
        textAlign: 'center',
        fontSize: 18,
        fontWeight: 'bold',
    },
    headerSave: {
        marginLeft: 10,
    },
    headerSaveText: {
        fontSize: 16,
        color: 'gray',
    },
    reasonContainer: {
        marginTop: 20,
    },
    checkboxContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: 10,
    },
    checkbox: {
        width: 24,
        height: 24,
        borderWidth: 1,
        borderRadius: 4,
        borderColor: 'black',
        marginRight: 10,
        justifyContent: 'center',
        alignItems: 'center',
    },
    checkboxLabel: {
        fontSize: 16,
    },
    otherReasonInput: {
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 4,
        marginTop: 10,
        padding: 8,
    },
});

export default ReportUser;
