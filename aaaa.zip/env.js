export const BASE_URL =
  "https://genzstyleappapi20240126141439.azurewebsites.net/";
