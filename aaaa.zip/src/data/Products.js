const products = [
    {
        id: "1",
        hashtag: "#styhint",
        image: "https://cdn.pixabay.com/photo/2023/09/16/18/26/hummingbird-8257355_1280.jpg"
    },
    {
        id: "2",
        hashtag: "#styhint",
        image: "https://cdn.pixabay.com/photo/2023/09/16/18/26/hummingbird-8257355_1280.jpg"
    },
    {
        id: "3",
        hashtag: "#styhint",
        image: "https://cdn.pixabay.com/photo/2023/09/16/18/26/hummingbird-8257355_1280.jpg"
    },
    {
        id: "4",
        hashtag: "#styhint",
        image: "https://cdn.pixabay.com/photo/2023/09/16/18/26/hummingbird-8257355_1280.jpg"
    },
    {
        id: "5",
        hashtag: "#styhint",
        image: "https://cdn.pixabay.com/photo/2023/09/16/18/26/hummingbird-8257355_1280.jpg"
    },
    {
        id: "6",
        hashtag: "#styhint",
        image: "https://cdn.pixabay.com/photo/2023/09/16/18/26/hummingbird-8257355_1280.jpg"
    },
    {
        id: "7",
        hashtag: "#styhint",
        image: "https://cdn.pixabay.com/photo/2023/09/16/18/26/hummingbird-8257355_1280.jpg"
    }
]
export default products;