// import React from 'react';
// import { View, StyleSheet } from 'react-native';
// import HeaderProfile from '../components/Profile/HeaderProfile';
// import ProfileTab from '../components/Profile/ProfileTab';
// import { useSelector } from 'react-redux';
// const ProfileScreen = () => {
//     const userInfo = useSelector((state) => state.user.userInfo);
//     // const accountId = useSelector((state) => state.user.accountId);

//     return (
//         <View style={styles.container}>
//             <HeaderProfile userInfo={userInfo} />
//             <View style={styles.hr} />
//             <ProfileTab />

//         </View>
//         // <View style={styles.container}>
//         //     <HeaderProfile userInfo={accountId} />
//         //     <View style={styles.hr} />
//         //     <ProfileTab />

//         // </View>
//     );
// };

// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         backgroundColor: 'white',
//     },
//     hr: {
//         borderBottomColor: 'lightgray',
//         borderBottomWidth: 1,
//         marginTop: 20,

//     },


// });

// export default ProfileScreen;
// import React, { useEffect, useState } from 'react';
// import { View, StyleSheet, ActivityIndicator, Text } from 'react-native';
// import HeaderProfile from '../components/Profile/HeaderProfile';
// import ProfileTab from '../components/Profile/ProfileTab';
// import { useSelector } from 'react-redux';

// const ProfileScreen = () => {
//     const [loading, setLoading] = useState(true);
//     const [userData, setUserData] = useState(null);
//     const [username, setUsername] = useState(null); // Add state to store username
//     const accountId = useSelector((state) => state.user.accountId);

//     useEffect(() => {
//         const fetchUserData = async () => {
//             try {
//                 const key = accountId;
//                 const response = await fetch(`https://genzstyleappapi20240126141439.azurewebsites.net/api/Users/Get/odata/Users/${key}/GetUserByAccountId`);
//                 const data = await response.json();
//                 setUserData(data);
//                 setLoading(false);
//                 if (data?.data?.accounts?.length > 0) {
//                     const fetchedUsername = data.data.accounts[0].username;
//                     setUsername(fetchedUsername); // Set the username state
//                     console.log("Username from ProfileScreen:", fetchedUsername);
//                 }
//             } catch (error) {
//                 console.error('Error fetching user data:', error);
//                 setLoading(false);
//             }
//         };

//         fetchUserData();
//     }, [accountId]);

//     return (
//         <View style={styles.container}>
//             {loading ? (
//                 <ActivityIndicator size="large" color="blue" />
//             ) : userData ? (
//                 <>
//                     <HeaderProfile userInfo={userData} username={username} />
//                     <View style={styles.hr} />
//                     <ProfileTab userData={userData} />
//                 </>
//             ) : (
//                 <Text>Error loading user data</Text>
//             )}
//         </View>
//     );
// };

// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         backgroundColor: 'white',
//     },
//     hr: {
//         borderBottomColor: 'lightgray',
//         borderBottomWidth: 1,
//         marginTop: 20,
//     },
// });

// export default ProfileScreen;

import React, { useEffect, useState } from 'react';
import { View, StyleSheet, ActivityIndicator, Text } from 'react-native';
import HeaderProfile from '../components/Profile/HeaderProfile';
import ProfileTab from '../components/Profile/ProfileTab';
import { useSelector } from 'react-redux';

const ProfileScreen = () => {
    const [loading, setLoading] = useState(false);
    const [userData, setUserData] = useState(null);
    const [username, setUsername] = useState(null);
    const accountId = useSelector((state) => state.user.accountId);

    useEffect(() => {
        const fetchUserData = async () => {
            try {
                const key = accountId;
                const response = await fetch(`https://genzstyleappapi20240126141439.azurewebsites.net/api/Users/Get/odata/Users/${key}/GetUserByAccountId`);
                const data = await response.json();
                setUserData(data);
                setLoading(false);
                if (data?.data?.accounts?.length > 0) {
                    const fetchedUsername = data?.data?.accounts[0]?.username;
                    setUsername(fetchedUsername); // Set the username state
                    console.log("Username from ProfileScreen:", fetchedUsername);
                }
            } catch (error) {
                console.error('Error fetching user data:', error);
                setLoading(false);
            }
        };

        fetchUserData();
    }, [accountId]);

    return (
        <View style={styles.container}>

            <HeaderProfile userInfo={userData} username={username} />
            <View style={styles.hr} />
            <ProfileTab userData={userData} />

        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    hr: {
        borderBottomColor: 'lightgray',
        borderBottomWidth: 1,
        marginTop: 20,
    },
});

export default ProfileScreen;

